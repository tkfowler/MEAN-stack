var mathlib = require('./mathlib')();
mathlib.add(1,10);
mathlib.multiply(10,10);
mathlib.square(3);
mathlib.random(1,100);
